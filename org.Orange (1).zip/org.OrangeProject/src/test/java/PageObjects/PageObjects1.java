package PageObjects;

import org.junit.Assert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.interactions.Actions;

public class PageObjects1 {
	
	public WebDriver ldriver;
	public PageObjects1(WebDriver rdriver)
	{
		ldriver=rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	//TC_123
	@FindBy(xpath="//input[@name='username']")
	@CacheLookup
	public WebElement txtUserName;
	

	@FindBy(xpath="//input[@type='password']")
	@CacheLookup
	public WebElement txtPassword;
	

	@FindBy(xpath="//button[@type='submit']")
	@CacheLookup
	public WebElement btnLogin;
	
	@FindBy(xpath="//span/h6[text()='Dashboard']")
	@CacheLookup
	public WebElement titlename;
	
	@FindBy(xpath="//p[text()='Invalid credentials']")
	@CacheLookup
	public WebElement errormsg;
	
	@FindBy (xpath="//span[text()='Required']")
	@CacheLookup
	public WebElement usreqmsg;
	
	//TC_456
	@FindBy (xpath="//span[text()='My Info']")
	@CacheLookup
	public WebElement myinfo;
	
	@FindBy(xpath="//body/div[@id='app']/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/form[1]/div[2]/div[1]/div[1]/div[1]/div[2]/input[1]")
	@CacheLookup
	public WebElement empid;
	
	@FindBy(xpath="//body/div[@id='app']/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/form[1]/div[2]/div[2]/div[1]/div[1]/div[2]/input[1]")
	@CacheLookup
	public WebElement licnum;
	
	@FindBy(xpath="//body/div[@id='app']/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/form[1]/div[2]/div[3]/div[1]/div[1]/div[2]/input[1]")
	@CacheLookup
	public WebElement ssnnum;
	
	@FindBy(xpath="//body/div[@id='app']/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/form[1]/div[2]/div[3]/div[2]/div[1]/div[2]/input[1]")
	@CacheLookup
	public WebElement sinnum;
	
	@FindBy(xpath="//body/div[@id='app']/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/input[1]")
	@CacheLookup
	public WebElement dob;
	
	@FindBy(xpath="//input[@name='firstName']")
	@CacheLookup
	public WebElement firstname;
	
	@FindBy(xpath="//button[@type='submit']")
	@CacheLookup
	public WebElement savebtn;
	
	@FindBy(xpath="//input[@name='middleName']")
	@CacheLookup
	public WebElement middlename;
	
	//TC_7_12
	
	@FindBy(xpath="//input[@type='file']")
	@CacheLookup
	public WebElement uploadfile;
	
	@FindBy(xpath="//span[text()='File type not allowed']")
	@CacheLookup
	public WebElement docnotallowed;
	
	@FindBy(xpath="//span[text()='Attachment Size Exceeded']")
	@CacheLookup
	public WebElement Exceededfile;
	
	//TC_13
	@FindBy(xpath="//img[@alt='client brand banner']")
	@CacheLookup
	public WebElement HRMlogo;
	
	@FindBy(xpath="//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name']")
	@CacheLookup
	public WebElement Adminpage;
	
	@FindBy(xpath="//h5[text()='System Users']")
	@CacheLookup
	public WebElement Systemusertext;
	
	@FindBy(xpath="//span[text()='Time']")
	@CacheLookup
	public WebElement TimePage;
	
	@FindBy(xpath="//input[@placeholder='Type for hints...']")
	@CacheLookup
	public WebElement Empnametab;
	
	@FindBy(xpath="//span[text()='Invalid']")
	@CacheLookup
	public WebElement Invalidtext;
	
	//TC_15
	@FindBy(xpath="//header[@class='oxd-topbar']/div[1]")
	@CacheLookup
	public WebElement backheadercolor;
	
	@FindBy(xpath="//header/div[1]")
	@CacheLookup
	public WebElement myinfoheader;
	
	//TC_19
	@FindBy(xpath="//div[@class='oxd-layout']")
	@CacheLookup
	public WebElement homepage;
	
	//TC_20
	@FindBy(xpath="//li[@class='oxd-topbar-body-nav-tab --parent --visited']//span[text()='User Management ']")
	@CacheLookup
	public WebElement usermanagement;
	
	@FindBy(xpath="//button[@class='oxd-button oxd-button--medium oxd-button--secondary']")
	@CacheLookup
	WebElement addbutton;
	
	@FindBy(xpath="//div[@class='oxd-select-text oxd-select-text--active']")
	@CacheLookup
	public WebElement userroledrop;
	
	@FindBy(xpath="//input[@placeholder='Type for hints...']")
	@CacheLookup
	public WebElement Employeename;
	
	@FindBy(xpath="(//div[@class='oxd-select-text oxd-select-text--active'])[2]")
	@CacheLookup
	public WebElement statusdropdown;
	
	@FindBy(xpath="(//input[@class='oxd-input oxd-input--active'])[2]")
	@CacheLookup
	public WebElement Employeeusername;
	
	@FindBy(xpath="//input[@type='password']")
	@CacheLookup
	public WebElement employeepassword;
	
	@FindBy(xpath="(//input[@type='password'])[2]")
	@CacheLookup
	public WebElement empconfrmpassword;
	
	@FindBy(xpath="//button[@type='submit']")
	@CacheLookup
	public WebElement usersavebutton;
	
	//TC_23
	@FindBy(xpath="//span[text()='Invalid']")
	@CacheLookup
	public WebElement invalidtext;
	
	@FindBy(xpath="//li[@class='oxd-topbar-body-nav-tab --parent']//span[text()='Job ']")
	@CacheLookup
	public WebElement jobdropdown;
	
	@FindBy(xpath="//ul[@class='oxd-dropdown-menu']//li/a[text()='Job Titles']")
	@CacheLookup
	public WebElement jobtitles;
	
	@FindBy(xpath="(//input[@class='oxd-input oxd-input--active'])[2]")
	@CacheLookup
	public WebElement enterjobtitle;
	
	@FindBy(xpath="//textarea[@placeholder='Type description here']")
	@CacheLookup
	public WebElement jobdescription;
	
	@FindBy(xpath="//div[@class='oxd-file-button']")
	@CacheLookup
	public WebElement jobspecification;
	
	@FindBy(xpath="//textarea[@placeholder='Add note']")
	@CacheLookup
	public WebElement addnote;
	
	@FindBy(xpath="//i[@class='oxd-icon bi-plus oxd-button-icon']")
	@CacheLookup
	public WebElement jobaddbtn;
	
	@FindBy(xpath="(//span[@class='oxd-checkbox-input oxd-checkbox-input--active --label-right oxd-checkbox-input']//i[1])[2]")
	@CacheLookup
	public WebElement jobcheckbox;
	
	@FindBy(xpath="//button[@class='oxd-button oxd-button--medium oxd-button--label-danger orangehrm-horizontal-margin']")
	@CacheLookup
	public WebElement jobdeleteselected;
	
	@FindBy(xpath="//button[@class='oxd-button oxd-button--medium oxd-button--label-danger orangehrm-button-margin']")
	@CacheLookup
	public WebElement jobyesdelete;
	
	//TC_25
	@FindBy(xpath="//ul[@class='oxd-dropdown-menu']//li/a[text()='Pay Grades']")
	@CacheLookup
	public WebElement jobpaygrades;
	
	@FindBy(xpath="//button[@class='oxd-button oxd-button--medium oxd-button--secondary']//i[@class='oxd-icon bi-plus oxd-button-icon']")
	@CacheLookup
	public WebElement jobpaygradesaddbtn;
	
	@FindBy(xpath="(//input[@class='oxd-input oxd-input--active'])[2]")
	@CacheLookup
	public WebElement namepaygrade;
	
	@FindBy(xpath="//div[@class='oxd-select-text oxd-select-text--active']")
	@CacheLookup
	public WebElement Currencypaygrades;
	
	@FindBy(xpath="(//input[@class='oxd-input oxd-input--active'])[3]")
	@CacheLookup
	public WebElement Mincurrency;
	
	@FindBy(xpath="(//input[@class='oxd-input oxd-input--active'])[3]")
	@CacheLookup
	public WebElement Maxcurrency;
	
	@FindBy(xpath="(//button[@type='submit'])[2]")
	@CacheLookup
	public WebElement currencysavebtn;
	
	//TC_26
	@FindBy(xpath="//ul[@class='oxd-dropdown-menu']//li/a[text()='Employment Status']")
	@CacheLookup
	public WebElement jobemploymentstatus;
	
	@FindBy(xpath="(//input[@class='oxd-input oxd-input--active'])[2]")
	@CacheLookup
	public WebElement nameEmpname;
	
	@FindBy(xpath="//p[@class='oxd-text oxd-text--p oxd-text--toast-message oxd-toast-content-text']")
	@CacheLookup
	public WebElement SuccessfullyUpadted;
	
	//TC_27
	@FindBy(xpath="//ul[@class='oxd-dropdown-menu']//li/a[text()='Job Categories']")
	@CacheLookup
	public WebElement jobcategories;
	
	@FindBy(xpath="(//input[@class='oxd-input oxd-input--active'])[2]")
	@CacheLookup
	public WebElement namejobcategories;


	
	
	
	
	
	
	
	
	
	public void setUsername(String username)
	{
		txtUserName.sendKeys(username);
	}
	
	public void setPassword(String password)
	{
		txtPassword.sendKeys(password);
	}
	
	public void clickSubmit()
	{
		btnLogin.click();
	}
	
	public void checktitle() {
		if(titlename.getText().contains("Dashboard")) {
			System.out.println("Login Was Succesfull with Valid Credentials");
		}
		else {
			System.out.println("Login was UnSuccesfull with Valid Credentials");
			ldriver.close();
		}
	}
	
	public void error_msg() {
		if(errormsg.getText().contains("Invalid credentials")) {
			System.out.println("Login Was UnSuccesfull with Invalid Credentials");
		}
		else {
			System.out.println("Login was Succesfull with invalid Credentials");
			ldriver.close();
		}
	}
	
	public void userreq_msg() {
		if(usreqmsg.getText().contains("Required")) {
			System.out.println("Required Message is Displayed");
		}
		else {
			System.out.println("Required Message is NoT Displayed");
		}
	}
	
	public void myinfopage()
	{
		myinfo.click();
	}
	
	public void Emp_id() {
		
		/*String value = empid.getAttribute("value");
		
		if (value!=null) {
			int vallen=value.length();
			for (int i=0; i<vallen; i++) {
				empid.sendKeys("");
			}
		}*/
		
		empid.sendKeys(Keys.CONTROL + "a");
		empid.sendKeys(Keys.DELETE);
		//empid.click();
		//empid.clear();
		empid.sendKeys("EMP1234");
		
	}
	
	public void Lic_num() {
		licnum.sendKeys(Keys.CONTROL + "a");
		licnum.sendKeys(Keys.DELETE);
		//licnum.click();
		//licnum.clear();
		licnum.sendKeys("1234");
		
	}
	
	public void ssn_num() {
		ssnnum.sendKeys(Keys.CONTROL + "a");
		ssnnum.sendKeys(Keys.DELETE);
		//ssnnum.click();
		//ssnnum.clear();
		ssnnum.sendKeys("123");
		
	}
	
	public void sin_num(){
		sinnum.sendKeys(Keys.CONTROL + "a");
		sinnum.sendKeys(Keys.DELETE);
		//sinnum.click();
		//sinnum.clear();
		sinnum.sendKeys("12");
		
	}
	
	public void dob_num(){
		dob.click();
		
	}
	
	public void first_name() throws InterruptedException{
		/*while (firstname.getAttribute("value").equals("")) {
			firstname.sendKeys(Keys.BACK_SPACE);
		}
		Thread.sleep(3000);*/
		firstname.sendKeys(Keys.CONTROL + "a");
		firstname.sendKeys(Keys.DELETE);
		//firstname.clear();
		firstname.sendKeys("Pavan");
		
	}
	
	public void save_btn(){
		savebtn.click();
		
	}
	
	public void middle_name(){
		middlename.sendKeys(Keys.CONTROL + "a");
		middlename.sendKeys(Keys.DELETE);
		//middlename.clear();
		middlename.sendKeys("Kumar");
		
	}
	
	public void upload_jpgfile() {
		uploadfile.sendKeys(System.getProperty("user.dir")+"//Files//SampleJPGImage_500kbmb.jpg");
	}
	
	public void upload_pngfile() {
		uploadfile.sendKeys(System.getProperty("user.dir")+"//Files//SamplePNGImage_500kbmb.png");
	}
	
	public void upload_giffile() {
		uploadfile.sendKeys(System.getProperty("user.dir")+"//Files//SampleGIFImage_350kbmb.gif");
	}
	
	public void upload_docfile() {
		uploadfile.sendKeys(System.getProperty("user.dir")+"//Files//SampleDOCFile_500kb.doc");
	}
	
	
	public void docnot_allowed() {
		if(docnotallowed.getText().contains("File type not allowed")) {
			System.out.println("Files with doc format are not allowed");
		}
		else {
			System.out.println("Files with doc format are allowed");
			ldriver.close();
		}
	}
	
	public void upload_morembjpgfile() {
		uploadfile.sendKeys(System.getProperty("user.dir")+"//Files//SampleJPGImage_2mbmb.jpg");
	}
	
	
	public void Exceeded_file() {
		if(Exceededfile.getText().contains("Attachment Size Exceeded")) {
			System.out.println("Uploaded File Size is Exceeded");
		}
		else {
			System.out.println("Uploaded File Size is Valid");
			ldriver.close();
		}
	}
	
	public void upload_morembpngfile() {
		uploadfile.sendKeys(System.getProperty("user.dir")+"//Files//SamplePNGImage_3mbmb.png");
	}
	
	public void HRM_logo_visible() {
		boolean logovisible=HRMlogo.isDisplayed();
		if(logovisible) {
			System.out.println("HRM logo was visible on default landed page");
		}
		else {
			System.out.println("HRM logo was not displayed on default landed page");
		}
	}
	
	public void Admin_page() {
		Adminpage.click();
	}
	
	public void System_user_text() {
		System.out.println("Font Size = " + Systemusertext.getCssValue("font-size"));
		System.out.println("Font Weight =" + Systemusertext.getCssValue("width"));
	}
	
	public void Time_Page(){
		TimePage.click();
		
		
	}
	
	public void Emp_name_tab() {
		Empnametab.sendKeys("John Collings");
		
	}
	
	public void Invalid_text() {
		if(Invalidtext.getText().contains("Invalid")) {
			System.out.println("Invalid text is displayed while user enters invalid employee name ");
		}
		else {
			System.out.println("User able to see time sheet of valid employee name");
			ldriver.close();
		}
	}
	
	public void Dashboard_header() {
		String palletExpectedColor = "rgba(255, 146, 11, 1)".trim();
		String dashbackcolor = backheadercolor.getCssValue("background-color").trim();
		System.out.println(dashbackcolor);	
		String hexbackcolor = Color.fromString(dashbackcolor).asHex();
		System.out.println(hexbackcolor);
		
		if(palletExpectedColor.equalsIgnoreCase(dashbackcolor)) {
			System.out.println("The color pallet in the Dashboard page is displayed correctly: " + dashbackcolor);
		}
		else {
			System.out.println("The color pallet in the Dashboard page is NOT displayed correctly: " + dashbackcolor);
		}
	}
	
	public void MyInfo_header() {
		String palletExpectedColor = "rgba(255, 146, 11, 1)".trim();
		String myinfobackcolor =myinfoheader.getCssValue("background-color").trim();
		System.out.println(myinfobackcolor);	
		String hexbackcolor = Color.fromString(myinfobackcolor).asHex();
		System.out.println(hexbackcolor);
		
		if(palletExpectedColor.equalsIgnoreCase(myinfobackcolor)) {
			System.out.println("The color pallet in the MyInfo page is displayed correctly: " + myinfobackcolor);
		}
		else {
			System.out.println("The color pallet in the MyInfo page is NOT displayed correctly: " + myinfobackcolor);
		}
	}
	
	public void user_management() {
		
		//Select dropdownuser=new Select(usermanagement);
		//dropdownuser.selectByVisibleText("Users");
		Actions act=new Actions(ldriver);
		act.click(usermanagement).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).build().perform();
		
		
	}
	
	public void add_button() {
		addbutton.click();
	}
	
	public void userrole_drop() {
		Actions act=new Actions(ldriver);
		act.click(userroledrop).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).build().perform();
		
	}
	
	public void Employee_name() {
		Employeename.sendKeys("P");
		Select sel = new Select(Employeename);
				sel.selectByIndex(1);
		//Actions act=new Actions(ldriver);
		//act.click(Employeename).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).build().perform();	
	}
	

	
	public void status_dropdown() {
		Actions act=new Actions(ldriver);
		act.click(statusdropdown).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).build().perform();
	}
	
	public void Employee_username() {
		Employeeusername.sendKeys("johnsmith");
	}
	public void employee_password() {
		employeepassword.sendKeys("John@123");
	}
	
	public void empconfrm_password() {
		empconfrmpassword.sendKeys("John@123");
	}
	
	public void usersave_button() {
		usersavebutton.click();
	}
	
	public void invalid_text() {
		String Expectedtext="Invalid";
		String Actualtext = invalidtext.getText();
		Assert.assertEquals(Actualtext,Expectedtext);
		System.out.println("Invalid text is displayed");
	}
	
	
	public void job_dropdown() {
		//Actions act=new Actions(ldriver);
		//act.click(jobdropdown).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).build().perform();
		jobdropdown.click();
		
	}
	
	public void job_titles() {
		jobtitles.click();
	}
	
	public void enter_jobtitle() {
		enterjobtitle.sendKeys("Engineer");
	}
	
	public void job_description() {
		jobdescription.sendKeys("Description for Engineer");
	}
	
	public void job_specification() {
		uploadfile.sendKeys(System.getProperty("user.dir")+"//Files//SampleDOCFile_500kb.doc");
	}
	
	public void add_note() {
		addnote.sendKeys("Add a note for Engineer");
	}
	
	public void job_checkbox() {
		jobcheckbox.click();
	}
	
	public void job_deleteselected() {
		jobdeleteselected.click();
	}
	
	public void job_yesdelete() {
		jobyesdelete.click();
	}
	
	public void job_paygrades() {
		jobpaygrades.click();
	}
	
	public void jobpaygrades_addbtn() {
		jobpaygradesaddbtn.click();
	}
	
	public void name_paygrade1() {
		namepaygrade.sendKeys("gradea");
	}
	
	public void name_paygrade2() {
		namepaygrade.sendKeys("gradeb");
	}
	
	public void name_paygrade3() {
		namepaygrade.sendKeys("gradec");
	}
	
	public void name_paygrade4() {
		namepaygrade.sendKeys("graded");
	}
	
	public void name_paygrade5() {
		namepaygrade.sendKeys("gradee");
	}
	
	public void Currency_paygrades1() {
		Actions act=new Actions(ldriver);
		act.click(Currencypaygrades).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).build().perform();
	    //Select objselect = new Select(Currencypaygrades);
	    //objselect.selectByVisibleText("INR - Indian Rupee");
	}
	
	public void Currency_paygrades2() {
		Actions act=new Actions(ldriver);
		act.click(Currencypaygrades).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).build().perform();
		
	}
	
	public void Currency_paygrades3() {
		Actions act=new Actions(ldriver);
		act.click(Currencypaygrades).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).build().perform();
		
	}
	
	public void Currency_paygrades4() {
		Actions act=new Actions(ldriver);
		act.click(Currencypaygrades).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).build().perform();
		
	}
	
	public void Currency_paygrades5() {
		Actions act=new Actions(ldriver);
		act.click(Currencypaygrades).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).build().perform();
		
	}
	
	public void Min_currency1() {
		Mincurrency.sendKeys("500");
	}
	
	public void Min_currency2() {
		Mincurrency.sendKeys("600");
	}
	
	public void Min_currency3() {
		Mincurrency.sendKeys("700");
	}
	
	public void Min_currency4() {
		Mincurrency.sendKeys("800");
	}
	
	public void Min_currency5() {
		Mincurrency.sendKeys("900");
	}
	
	public void Max_currency1() {
		Maxcurrency.sendKeys("1000");
	}
	
	public void Max_currency2() {
		Maxcurrency.sendKeys("2000");
	}
	
	public void Max_currency3() {
		Maxcurrency.sendKeys("3000");
	}
	
	public void Max_currency4() {
		Maxcurrency.sendKeys("4000");
	}
	
	public void Max_currency5() {
		Maxcurrency.sendKeys("5000");
	}
	
	public void currency_savebtn() {
		currencysavebtn.click();
	}
	
	public void job_employmentstatus() {
		jobemploymentstatus.click();
	}
	
	public void name_Empname1() {
		nameEmpname.sendKeys("Pavan");
	}
	
	public void name_Empname2() {
		nameEmpname.sendKeys("Yashwanth");
	}
	public void name_Empname3() {
		nameEmpname.sendKeys("Teja");
	}
	public void name_Empname4() {
		nameEmpname.sendKeys("Kumar");
	}
	public void name_Empname5() {
		nameEmpname.sendKeys("Venkat");
	}
	
	
	public void Successfully_Upadted() {
		boolean logovisible=SuccessfullyUpadted.isDisplayed();
		if(logovisible) {
			System.out.println("Successfully Updated Message is Displayed");
		}
		else {
			System.out.println("Successfully Updated Message is Not Displayed");
		}
	}
	
	public void job_categories() {
		jobcategories.click();
	}
	
	public void name_jobcategories1() {
		namejobcategories.sendKeys("Engineer");
	}
	
	public void name_jobcategories2() {
		namejobcategories.sendKeys("Architech");
	}
	public void name_jobcategories3() {
		namejobcategories.sendKeys("Literature");
	}
	public void name_jobcategories4() {
		namejobcategories.sendKeys("Associate Engineer");
	}
	public void name_jobcategories5() {
		namejobcategories.sendKeys("Analysts");
	}
}
	
	
	
	
	
	
	
	
	