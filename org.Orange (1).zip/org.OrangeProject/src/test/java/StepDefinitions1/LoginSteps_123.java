package StepDefinitions1;

import java.util.concurrent.TimeUnit;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import PageObjects.PageObjects1;
import io.cucumber.java.en.*;

public class LoginSteps_123 {
	
	public WebDriver driver=null;
	public PageObjects1 lp;
	
	@SuppressWarnings("deprecation")
	@Given("User is initializing the browser with chrome")
	public void user_is_initializing_the_browser_with_chrome() {
		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"//Drivers//chromedriver.exe");
		//System.setProperty("webdriver.chrome.driver","C:\\Users\\GARAPAVA\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		
		//System.setProperty("webdriver.gecko.driver", "./Drivers/geckodriver.exe");
		//driver=new FirefoxDriver();
		
		lp=new PageObjects1(driver);
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		
	}

	@When("User is navigate to login page {string} site")
	public void user_is_navigate_to_login_page_site(String url) throws InterruptedException {
		driver.get(url);
		Thread.sleep(2000);
	}

	@When("User enters userName as {string} and Password as {string}")
	public void user_enters_user_name_as_and_password_as(String username, String password) {
       lp.setUsername(username);
       lp.setPassword(password);
	}

	@When("clicks on Login button")
	public void clicks_on_login_button() {
	   lp.clickSubmit();
	}
	
//TestScenario1
	
	@Then("Checks the Page Title should be {string}")
	public void checks_the_page_title_should_be(String string) {
		lp.checktitle();
	}

	@Then("close the browser")
	public void close_the_browser() {
		driver.quit();
	}
	
//TestScenario2
	
	@Then("Checks invalid credentials is present {string}")
	public void checks_invalid_credentials_is_present(String string) {
		lp.error_msg();
	}
	
//TestScenario3	
	
	@Then("Checking the text under the password box {string}")
	public void checking_the_text_under_the_password_box(String string) {
		lp.userreq_msg();
	}
	
	@Then("Checking the text under the username box {string}")
	public void checking_the_text_under_the_username_box(String string) {
		lp.userreq_msg();
	}
			
}
