package StepDefinitions1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageObjects.PageObjects1;
import io.cucumber.java.en.*;

public class LoginSteps_13 {
	public WebDriver driver=null;
	public PageObjects1 lp;
	public long pageLoadTime;
	
	@SuppressWarnings("deprecation")
	@Given("User Is Initializing The Browser")
	public void user_is_initializing_the_browser() {
		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"//Drivers//chromedriver.exe");
		driver = new ChromeDriver();
		
		lp=new PageObjects1(driver);
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@When("User Is Navigating To Login Page {string}")
	public void user_is_navigating_to_login_page(String url) throws InterruptedException {
		driver.get(url);
		
	}
	
	@Then("User measure the page loading time by giving the url {string}")
	public void user_measure_the_page_loading_time_by_giving_the_url(String url) {
        long start=System.currentTimeMillis();
		driver.get(url);
		long finish=System.currentTimeMillis();
		long Total_Time=(finish-start)/1000;
		System.out.println("Total page load time: "+Total_Time+"seconds");
		if(Total_Time>10) {
			System.out.println("Page load time is more that expected");
		}
		else {
			System.out.println("Hurray Its loading quickly");
		}
	}

	@Then("Close The Browser")
	public void close_the_browser() {
	    driver.quit();
	}

	@When("User Enters The Username as {string} and Password as {string}")
	public void user_enters_the_username_as_and_password_as(String username, String password) {
		lp.setUsername(username);
	    lp.setPassword(password);
	}

	@Then("Clicks on the Login Button")
	public void clicks_on_the_login_button() {
		lp.clickSubmit();
	}

	@Then("User able to navigate to Dashboard Page")
	public void user_able_to_navigate_to_dashboard_page() {
		lp.checktitle();
	}

	@Then("user is able to see the Logo")
	public void user_is_able_to_see_the_logo() {
		lp.HRM_logo_visible();
	}

	@Then("User is able to click the Admin tab")
	public void user_is_able_to_click_the_Admin_tab() {
	    lp.Admin_page();
	    
	}

	@Then("User is able to check the SystemUser fontsize and width")
	public void User_is_able_to_check_the_SystemUser_fontsize_and_width() {
		lp.System_user_text();
	}

	@Then("User is able to click the Time tab")
	public void user_is_able_to_click_the_Time_tab() {
	    lp.Time_Page();
	    
	}

	@Then("User is able to enter the employee name")
	public void user_is_able_to_enter_the_employee_name() {
	    lp.Emp_name_tab();
	}

	@Then("User is able to click on the save button")
	public void User_is_able_to_click_on_the_save_button() throws InterruptedException {
		lp.save_btn();
		Thread.sleep(2000);
		
		
	}
    @Then("User able to see Invalid text")
    public void User_able_to_see_Invalid_text() {
    	lp.Invalid_text();
 
    }


}
