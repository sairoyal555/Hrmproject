package StepDefinitions1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageObjects.PageObjects1;
import io.cucumber.java.en.*;

public class LoginSteps_14 {
	public WebDriver driver=null;
	public PageObjects1 lp;
	
	@SuppressWarnings("deprecation")
	@Given("User is able to open the browser and set to pixels")
	public void user_is_able_to_open_the_browser_and_set_to_pixels() {
		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"//Drivers//chromedriver.exe");
		driver = new ChromeDriver();
		lp=new PageObjects1(driver);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().setSize(new Dimension(640,480));
	}
	

	@When("User is navigate to website  {string}")
	public void user_is_navigate_to_website(String url) throws InterruptedException {
		driver.get(url);
		Thread.sleep(2000);
	}

	@Then("User is able to check all pages fit in the web browser window")
	public void user_is_able_to_check_all_pages_fit_in_the_web_browser_window() {
		Dimension screenSize = driver.manage().window().getSize();
	    int screenWidth = screenSize.width;
		int screenHeight = screenSize.height;
		System.out.println("Screen resolution is " + screenWidth + "*" + screenHeight);
	    
	}
	
	@Then("User will login with username {string} and password {string}")
	public void user_will_login_with_username_and_password(String username, String password) {
		 lp.setUsername(username);
	     lp.setPassword(password);
		 lp.clickSubmit();
	}

	@Then("User checking the Dashboard title")
	public void user_checking_the_dashboard_title() {
		lp.checktitle();
	}

	@Then("close the browser.")
	public void close_the_browser() {
	    driver.quit();
	}

}
