package StepDefinitions1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageObjects.PageObjects1;
import io.cucumber.java.en.*;

public class LoginSteps_15 {
	public WebDriver driver=null;
	public PageObjects1 lp;

@SuppressWarnings("deprecation")
@Given("User opens the browser")
public void user_opens_the_browser() {
	System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"//Drivers//chromedriver.exe");
	driver = new ChromeDriver();
	lp=new PageObjects1(driver);
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
}

@Then("user navigates to the URL   {string}")
public void user_navigates_to_the_url(String url) throws InterruptedException {
	driver.get(url);
	Thread.sleep(2000);
}

@When("User able to login using username {string} and password {string}")
public void user_able_to_login_using_username_and_password(String username, String password) {
	lp.setUsername(username);
    lp.setPassword(password);
	 
}

@Then("login to the dashboard page")
public void login_to_the_dashboard_page() {
	lp.clickSubmit();
}

@Then("user gets the dashboard header background colour")
public void user_gets_the_dashboard_header_background_colour() throws InterruptedException {
	lp.Dashboard_header();
	Thread.sleep(2000);
}

@Then("User click on the MyInfo page")
public void user_click_on_the_my_info_page() throws InterruptedException {
	lp.myinfopage();
	Thread.sleep(2000);
}


@Then("User navigated to myinfo page url  {string}")
public void user_navigated_to_myinfo_page_url(String url) throws InterruptedException {
	driver.get(url);
	Thread.sleep(2000);
}


@Then("user gets the myinfo header background colour")
public void user_gets_the_myinfo_header_background_colour() throws InterruptedException {
    lp.MyInfo_header();
    Thread.sleep(2000);
    
}

@Then("closes the browser..")
public void closes_the_browser() {
    driver.quit();
}


}
