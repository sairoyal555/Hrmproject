package StepDefinitions1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import PageObjects.PageObjects1;
import io.cucumber.java.en.*;

public class LoginSteps_16 {
	
	public WebDriver driver=null;
	public PageObjects1 lp;
	
	@SuppressWarnings("deprecation")
	@Given("User is initializing the browser with edge")
	public void user_is_initializing_the_browser_with_edge() {
		System.setProperty("webdriver.edge.driver",System.getProperty("user.dir")+"//Drivers//msedgedriver.exe");
		driver = new EdgeDriver();
		lp=new PageObjects1(driver);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	@SuppressWarnings("deprecation")
	@Given("User is initializing the browser with Firefox")
	public void user_is_initializing_the_browser_with_Firefox() {
		System.setProperty("webdriver.edge.driver",System.getProperty("user.dir")+"//Drivers//geckodriver.exe");
		driver = new FirefoxDriver();
		lp=new PageObjects1(driver);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@When("User is able to login the page {string}")
	public void user_is_able_to_login_the_page(String url) throws InterruptedException {
		driver.get(url);
		Thread.sleep(2000);
	}

	@Then("User enters the credentials Username as {string} and Password as {string}")
	public void user_enters_the_credentials_username_as_and_password_as(String username, String password) {
		lp.setUsername(username);
	    lp.setPassword(password);
	
	}

	@Then("clicks on the Login button")
	public void clicks_on_the_login_button() {
		 lp.clickSubmit();
	}

	@Then("Checks the dashboard Page Title should be {string}")
	public void checks_the_dashboard_page_title_should_be(String string) {
	    lp.checktitle();
	}

	@Then("closes the browser.")
	public void closes_the_browser() {
	    driver.quit();
	}

}
