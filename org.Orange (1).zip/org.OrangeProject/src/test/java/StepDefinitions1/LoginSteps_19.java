package StepDefinitions1;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import PageObjects.PageObjects1;
import io.cucumber.java.en.*;

public class LoginSteps_19 {
	public WebDriver driver=null;
	public PageObjects1 lp;
	
	@SuppressWarnings("deprecation")
	@Given("user is Open the browser with Chrome")
	public void user_is_open_the_browser_with_chrome() {
		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"//Drivers//chromedriver.exe");
		driver = new ChromeDriver();
		
		lp=new PageObjects1(driver);
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@When("user is able to login the web page {string}")
	public void user_is_able_to_login_the_web_page(String url) throws InterruptedException {
		driver.get(url);
		Thread.sleep(2000);
	}

	@Then("user given the credentials Username as {string} and Password as {string}")
	public void user_given_the_credentials_username_as_and_password_as(String username, String password) {
		lp.setUsername(username);
	    lp.setPassword(password);
	}

	@Then("user clicks on the Login button")
	public void user_clicks_on_the_login_button() {
		lp.clickSubmit();
	}

	@Then("user Checks the Dashboard Page title should be {string}")
	public void user_checks_the_dashboard_page_title_should_be(String string) {
		lp.checktitle();
	}

	@Then("User gets the count of static images")
	public void user_gets_the_count_of_static_images() {
	WebElement images=driver.findElement(By.tagName("img"));
	System.out.println(images.getSize());
	    
	}

	@Then("user closes the browser.")
	public void user_closes_the_browser() {
		driver.quit();
	}


}
