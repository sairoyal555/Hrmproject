package StepDefinitions1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageObjects.PageObjects1;
import io.cucumber.java.en.*;

public class LoginSteps_20to22 {
	public WebDriver driver=null;
	public PageObjects1 lp;
	

@Given("user is Launch the browser with Chrome")
public void user_is_launch_the_browser_with_chrome() {
	System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"//Drivers//chromedriver.exe");
	driver = new ChromeDriver();
	
	lp=new PageObjects1(driver);
	
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
}

@When("user is login to the web page {string}")
public void user_is_login_to_the_web_page(String url) throws InterruptedException {
	driver.get(url);
	Thread.sleep(2000);
}

@Then("user giving the credentials Username as {string} and Password as {string}")
public void user_giving_the_credentials_username_as_and_password_as(String username, String password) {
	lp.setUsername(username);
    lp.setPassword(password);
}

@Then("user clicking on the Login button")
public void user_clicking_on_the_login_button() {
	lp.clickSubmit();
}

@Then("user Clicks on Admin")
public void user_clicks_on_admin() {
	lp.Admin_page();
}

@Then("User selects the users from user management dropdown")
public void user_selects_the_users_from_user_management_dropdown() throws InterruptedException {
	lp.user_management();
	Thread.sleep(3000);
}

@And("Click on add button")
public void click_on_add_button() {
	lp.add_button();
}

@Then("user select the user from userrole dropdown")
	public void user_select_the_user_from_userrole_dropdown() throws InterruptedException {
	lp.userrole_drop();
	Thread.sleep(3000);
	
}


@Then("user enters the employee name")
public void user_enters_the_employee_name() {
	lp.Employee_name();
}

@Then("user select the status of employee")
public void user_select_the_status_of_employee() {
	lp.status_dropdown();
}

@Then("user enters the username")
public void user_enters_the_username() {
    lp.Employee_username();
}

@Then("user enters the password")
public void user_enters_the_password() {
    lp.employee_password();
}

@And("user enters the confirm password")
public void user_enters_the_confirm_password() {
	lp.empconfrm_password();
}

@Then("user see invalid text")
public void user_see_invalid_text() {
	lp.invalid_text();
}

/*@Then("clicks on save button")
public void clicks_on_save_button() throws InterruptedException{
	lp.usersave_button();
	Thread.sleep(3000);
}*/

@Then("teardown the browser.")
public void teardown_the_browser() {
    //driver.quit();
}

}
