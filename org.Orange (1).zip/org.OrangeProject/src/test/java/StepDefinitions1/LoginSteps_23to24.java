package StepDefinitions1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageObjects.PageObjects1;
import io.cucumber.java.en.*;

public class LoginSteps_23to24 {
	public WebDriver driver=null;
	public PageObjects1 lp;
	
	@SuppressWarnings("deprecation")
	@Given("User Launch The Browser")
	public void user_launch_the_browser() {
		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"//Drivers//chromedriver.exe");
		driver = new ChromeDriver();
		lp=new PageObjects1(driver);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Then("User Navigating To URL {string}")
	public void user_navigating_to_url(String url) throws InterruptedException {
		driver.get(url);
		Thread.sleep(2000);
	}

	@When("User Enters The Username As {string} and Password As {string}")
	public void user_enters_the_username_as_and_password_as(String username, String password) {
		lp.setUsername(username);
	    lp.setPassword(password);
	}

	@Then("User Clicks On The button")
	public void user_clicks_on_the_button() {
		lp.clickSubmit();
	}

	@Then("User Need To Navigate To Admin Page")
	public void user_need_to_navigate_to_admin_page() {
		lp.Admin_page();
	}

	@When("User Select The Job Dropdown")
	public void user_select_the_job_dropdown() {
		lp.job_dropdown();
	}

	@Then("Click On JobTitles From Dropdown")
	public void click_on_job_titles_from_dropdown() throws InterruptedException {
	    lp.job_titles();
	    Thread.sleep(2000);
	}

	@When("Click On Add button")
	public void click_on_add_button() throws InterruptedException {
		lp.add_button();
		Thread.sleep(2000);
	}

	@When("User Enter The Job Title")
	public void user_enter_the_job_title() {
	    lp.enter_jobtitle();
	}

	@When("User Enters The JobDescription and Note")
	public void user_enters_the_job_description_and_note() {
	    lp.job_description();
	}

	@When("User Can Upload The Job Specification Files Lessthan 1Mb")
	public void user_can_upload_the_job_specification_files_lessthan_1mb() {
	    lp.job_specification();
	}
	
	@When("User Can Upload The Job Specification Files morethan 1Mb")
	public void user_can_upload_the_job_specification_files_morethan_1mb() {
	    lp.upload_morembjpgfile();
	}

	@When("Click On Save")
	public void click_on_save() {
	    lp.save_btn();
	}
	
	@And("User Able To See Required message on Mandatary field")
	public void user_able_to_see_required_message_on_mandatary_field() {
		lp.userreq_msg();
	}
	
	@And("User Able To See Attachment Size Exceeded message under job Specification field")
	public void user_able_to_see_attachment_size_exceeded_message_under_job_specification_field() {
		lp.Exceeded_file();
	}
	
	@Then("Click On The Checkbox")
	public void click_on_the_checkbox() {
	    lp.job_checkbox();
	}

	@Then("Click On the Delete Selected button")
	public void click_on_the_delete_selected_button() {
	    lp.job_deleteselected();
	}

	@Then("Click On the yes Delete button")
	public void click_on_the_yes_delete_button() {
	    lp.job_yesdelete();
	}

	@When("Tear Down The Browser")
	public void tear_down_the_browser() {
	    driver.quit();
	}
	
}
