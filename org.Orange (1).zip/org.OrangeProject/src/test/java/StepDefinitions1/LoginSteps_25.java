package StepDefinitions1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageObjects.PageObjects1;
import io.cucumber.java.en.*;

public class LoginSteps_25 {
	public WebDriver driver=null;
	public PageObjects1 lp;
	
	@SuppressWarnings("deprecation")
	@Given("User Is Launching the browser..")
	public void user_is_launching_the_browser() {
		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"//Drivers//chromedriver.exe");
		driver = new ChromeDriver();
		lp=new PageObjects1(driver);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Then("User navigating To The.. Url {string}")
	public void user_navigating_to_the_url(String url) throws InterruptedException {
		driver.get(url);
		Thread.sleep(2000);
	}

	@When("User Enters The Username.. As {string} and Password As {string}")
	public void user_enters_the_username_as_and_password_as(String username, String password) {
		lp.setUsername(username);
	    lp.setPassword(password);
	}

	@Then("User Clicks On The button..")
	public void user_clicks_on_the_button() {
		lp.clickSubmit();
	}

	@Then("User Need To Navigate To Admin Page..")
	public void user_need_to_navigate_to_admin_page() {
		lp.Admin_page();

	}

	@When("User Select The Job Dropdown..")
	public void user_select_the_job_dropdown() {
	    lp.job_dropdown();
	}

	@Then("Click On PayGrades From Dropdown..")
	public void click_on_pay_grades_from_dropdown() {
	    lp.job_paygrades();
	    
	}

	@When("Click On Add button..")
	public void click_on_add_button() {
	    lp.add_button();
	}
	
	@When("User given Name1..")
	public void user_given_name1() {
	    lp.name_paygrade1();
	}

	@When("Click on Save..")
	public void click_on_save() throws InterruptedException {
	    lp.usersave_button();
	    Thread.sleep(2000);
	}
	
	@Then("Click on Currency Add button")
	public void click_on_currency_add_button() throws InterruptedException {
		lp.jobpaygrades_addbtn();
		Thread.sleep(2000);
	}

	@When("User given currency1 from dropdown..")
	public void user_given_currency1_from_dropdown() throws InterruptedException {
		lp.Currency_paygrades1();
		Thread.sleep(2000);
	}

	@Then("User given Minimum1 Salary..")
	public void user_given_minimum1_salary() {
	    lp.Min_currency1();
	}

	@When("User given Maximum1 Salary..")
	public void user_given_maximum1_salary() {
	    lp.Max_currency1();
	}

	@Then("Click on Currency Save button..")
	public void click_on_currency_save_button() {
	    lp.currency_savebtn();
	}
	
	@And("user can See Successfully Updated message is displayed")
	public void user_can_see_successfully_updated_message_is_displayed() {
	    lp.Successfully_Upadted();
	}
	
	@When("User given Name2..")
	public void user_given_name2() {
		lp.name_paygrade2();
	}

	@When("User given currency2 from dropdown..")
	public void user_given_currency2_from_dropdown() throws InterruptedException {
		lp.Currency_paygrades2();
		Thread.sleep(2000);
	}

	@Then("User given Minimum2 Salary..")
	public void user_given_minimum2_salary() {
		lp.Min_currency2();
		
	}

	@When("User given Maximum2 Salary..")
	public void user_given_maximum2_salary() {
		lp.Max_currency2();
	}

	@When("User given Name3..")
	public void user_given_name3() {
		lp.name_paygrade3();
	}

	@When("User given currency3 from dropdown..")
	public void user_given_currency3_from_dropdown() throws InterruptedException {
		lp.Currency_paygrades3();
		Thread.sleep(2000);
	}

	@Then("User given Minimum3 Salary..")
	public void user_given_minimum3_salary() {
	    lp.Min_currency3();
	}

	@When("User given Maximum3 Salary..")
	public void user_given_maximum3_salary() {
	    lp.Max_currency3();
	}

	@When("User given Name4..")
	public void user_given_name4() {
		lp.name_paygrade4();
	}

	@When("User given currency4 from dropdown..")
	public void user_given_currency4_from_dropdown() throws InterruptedException {
		lp.Currency_paygrades4();
		Thread.sleep(2000);
	}

	@Then("User given Minimum4 Salary..")
	public void user_given_minimum4_salary() {
	    lp.Min_currency4();
	}

	@When("User given Maximum4 Salary..")
	public void user_given_maximum4_salary() {
	    lp.Max_currency4();
	}

	@When("User given Name5..")
	public void user_given_name5() {
		lp.name_paygrade5();
	}

	@When("User given currency5 from dropdown..")
	public void user_given_currency5_from_dropdown() throws InterruptedException {
		lp.Currency_paygrades5();
		Thread.sleep(2000);
	}

	@Then("User given Minimum5 Salary..")
	public void user_given_minimum5_salary() {
	    lp.Min_currency5();
	}

	@When("User given Maximum5 Salary..")
	public void user_given_maximum5_salary() {
	    lp.Max_currency5();
	}


	@Then("Click On Checkbox..")
	public void click_on_checkbox() {
		lp.job_checkbox();
	}

	@Then("Click On Delete Selected button..")
	public void click_on_delete_selected_button() {
		lp.job_deleteselected();
	}

	@Then("Click On yes Delete button..")
	public void click_on_yes_delete_button() {
		lp.job_yesdelete();
	}

	@Then("Closes The BrowserS..")
	public void closes_the_browser_s() {
	    driver.quit();
	}

}
