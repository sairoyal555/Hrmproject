package StepDefinitions1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageObjects.PageObjects1;
import io.cucumber.java.en.*;

public class LoginSteps_26 {
	public WebDriver driver=null;
	public PageObjects1 lp;
	
	@SuppressWarnings("deprecation")
	@Given("launch Webbrowser")
	public void launch_webbrowser() {
		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"//Drivers//chromedriver.exe");
		driver = new ChromeDriver();
		lp=new PageObjects1(driver);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	@When("User open URL {string}")
	public void user_open_url(String url) throws InterruptedException {
		driver.get(url);
		Thread.sleep(2000);
	}


	@When("User will login as {string} and Password  {string}")
	public void user_will_login_as_and_password(String username, String password) {
		lp.setUsername(username);
	    lp.setPassword(password);
	}

	@When("clicks LOGIN button")
	public void clicks_login_button() {
		lp.clickSubmit();
	}

	@Then("user need to navigate to the ADMIN page")
	public void user_need_to_navigate_to_the_admin_page() {
		lp.Admin_page();
	}

	@When("user selects Employement Status from job dropdown")
	public void user_selects_employement_status_from_job_dropdown() {
		lp.job_dropdown();
		lp.job_employmentstatus();
		
	}

	@When("Click on Add button")
	public void click_on_add_button() {
		lp.add_button();
	}

	@When("user will enter employement status")
	public void user_will_enter_employement_status() {
	    lp.name_Empname1();
	}

	@When("user clicks save button")
	public void user_clicks_save_button() throws InterruptedException {
	    lp.usersave_button();
	    Thread.sleep(2000);
	}

	@When("user can see successfully updated message is displayed")
	public void user_can_see_successfully_updated_message_is_displayed() {
	    lp.Successfully_Upadted();
	}


	@When("user will enter name in employement status")
	public void user_will_enter_name_in_employement_status() {
		lp.name_Empname2();
	}

	@When("user enters employement status")
	public void user_enters_employement_status() {
		lp.name_Empname3();
	}

	@When("user will enter the employement status")
	public void user_will_enter_the_employement_status() {
		lp.name_Empname4();
	}

	@When("user will enter employement status name field")
	public void user_will_enter_employement_status_name_field() {
		lp.name_Empname5();
	}

	@Then("Click On Checkbox")
	public void click_on_checkbox() {
		lp.job_checkbox();
	}

	@Then("Click On Delete Selected button")
	public void click_on_delete_selected_button() {
	    lp.job_deleteselected();
	}

	@Then("Click On  yes Delete button")
	public void click_on_yes_delete_button() {
	    lp.job_yesdelete();
	}

	@Then("leave the browser")
	public void leave_the_browser() {
	    driver.quit();
	}

}
