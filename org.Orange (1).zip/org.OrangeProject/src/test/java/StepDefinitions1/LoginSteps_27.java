package StepDefinitions1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageObjects.PageObjects1;
import io.cucumber.java.en.*;

public class LoginSteps_27 {
	public WebDriver driver=null;
	public PageObjects1 lp;
	

@SuppressWarnings("deprecation")
@Given("User is launch Webbrowser")
public void user_is_launch_webbrowser() {
	System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"//Drivers//chromedriver.exe");
	driver = new ChromeDriver();
	lp=new PageObjects1(driver);
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
}

@When("User open URL the {string}")
public void user_open_url_the(String url) throws InterruptedException {
	driver.get(url);
	Thread.sleep(2000);
}

@When("User login as {string} and Password  {string}")
public void user_login_as_and_password(String username, String password) {
	lp.setUsername(username);
    lp.setPassword(password);

}

@When("click LOGIN button")
public void click_login_button() {
	lp.clickSubmit();
}

@Then("User navigate to the ADMIN page")
public void user_navigate_to_the_admin_page() {
	lp.Admin_page();
}

@When("user selects Job Categories from job dropdown")
public void user_selects_job_categories_from_job_dropdown() {
	lp.job_dropdown();
	lp.job_categories();
	
}

@When("Click on the Add button")
public void click_on_the_add_button() {
	lp.add_button();
}

@When("user will enter job category")
public void user_will_enter_job_category() {
    lp.name_jobcategories1();
}

@When("user clicks on to save button")
public void user_clicks_on_to_save_button() throws InterruptedException {
	lp.usersave_button();
    Thread.sleep(2000);
}

@When("user can see successfully updated message displayed")
public void user_can_see_successfully_updated_message_displayed() {
	lp.Successfully_Upadted();
}

@When("user will enter name in job category")
public void user_will_enter_name_in_job_category() {
	lp.name_jobcategories2();
}

@When("user enters job category")
public void user_enters_job_category() {
	lp.name_jobcategories3();
}

@When("user will enter the job category")
public void user_will_enter_the_job_category() {
	lp.name_jobcategories4();
}

@When("user will enter job category name field")
public void user_will_enter_job_category_name_field() {
	lp.name_jobcategories5();
}

@Then("Click Checkbox")
public void click_checkbox() {
	lp.job_checkbox();
}

@Then("Click Delete Selected button")
public void click_delete_selected_button() {
	lp.job_deleteselected();
}

@Then("Click yes Delete button")
public void click_yes_delete_button() {
	lp.job_yesdelete();
}

@Then("Close down the browser")
public void close_down_the_browser() {
    driver.quit();
    
}


}
