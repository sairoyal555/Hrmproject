package StepDefinitions1;

import java.util.concurrent.TimeUnit;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


import PageObjects.PageObjects1;
import io.cucumber.java.en.*;

public class LoginSteps_4to6 {
	
	public WebDriver driver=null;
	public PageObjects1 lp;

	@SuppressWarnings("deprecation")
	@Given("User is open the browser with chrome")
	public void user_is_open_the_browser_with_chrome() {
		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"//Drivers//chromedriver.exe");
		//System.setProperty("webdriver.chrome.driver","C:\\Users\\GARAPAVA\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		
		lp=new PageObjects1(driver);
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@When("User is navigated to login page {string}")
	public void user_is_navigated_to_login_page(String url) throws InterruptedException {
		driver.get(url);
		Thread.sleep(2000);

	}

	@When("User enters username as {string} and password as {string}")
	public void user_enters_username_as_and_password_as(String username, String password) {
		lp.setUsername(username);
	    lp.setPassword(password);
	}

	@When("clicks on login button")
	public void clicks_on_login_button() {
		 lp.clickSubmit();
	}

	@Then("click on the My Info")
	public void click_on_the_my_info() throws InterruptedException {
		lp.myinfopage();
		Thread.sleep(2000);
	}

	@Then("user enters the employee id {string}")
	public void user_enters_the_employee_id(String string) throws InterruptedException {
		lp.Emp_id();
		Thread.sleep(2000);
		
	}

	@Then("user enters the driver license number {string}")
	public void user_enters_the_driver_license_number(String string) throws InterruptedException {
		lp.Lic_num();
		Thread.sleep(2000);
		
	}

	@Then("user enters the SSN number as {string}")
	public void user_enters_the_ssn_number_as(String string) throws InterruptedException {
		lp.ssn_num();
		Thread.sleep(2000);
	}

	@Then("user enters the SIN number as {string}")
	public void user_enters_the_sin_number_as(String string) throws InterruptedException {
		lp.sin_num();
		Thread.sleep(2000);
	}

	@Then("Date of Birth as {string}")
	public void date_of_birth_as(String string) throws InterruptedException {
		lp.dob_num();
	    Thread.sleep(2000);
	}

	@Then("Close the browser")
	public void close_the_browser() {
		driver.quit();
	}
	
	@And("User enters the FirstName {string}")
	public void user_enters_the_first_name(String string) throws InterruptedException {
	  lp.first_name();
	  Thread.sleep(2000);
	  }
	
    @Then("user click on save button")
    public void user_click_on_save_button() throws InterruptedException {
    	lp.save_btn();
    	Thread.sleep(2000);
    }
    
    @And("User enters the MiddleName {string}")
	public void user_enters_the_middle_name(String string) throws InterruptedException {
	  lp.middle_name();
	  Thread.sleep(2000);
	  }
}


