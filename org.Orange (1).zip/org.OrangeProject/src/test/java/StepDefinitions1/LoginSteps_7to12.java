package StepDefinitions1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageObjects.PageObjects1;
import io.cucumber.java.en.*;

public class LoginSteps_7to12 {
	public WebDriver driver=null;
	public PageObjects1 lp;

@SuppressWarnings("deprecation")
@Given("User is initializing the browser")
public void user_is_initializing_the_browser() {
	System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"//Drivers//chromedriver.exe");
	driver = new ChromeDriver();
	
	lp=new PageObjects1(driver);
	
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
}

@When("User is navigating to login page {string}")
public void user_is_navigating_to_login_page(String url) throws InterruptedException {
	driver.get(url);
	Thread.sleep(2000);
}

@When("User enters the username as {string} and password as {string}")
public void user_enters_the_username_as_and_password_as(String username, String password) {
	lp.setUsername(username);
    lp.setPassword(password);
}

@When("clicks on the login button")
public void clicks_on_the_login_button() {
	lp.clickSubmit();
}

@Then("click on My Info")
public void click_on_my_info() throws InterruptedException {
	lp.myinfopage();
	Thread.sleep(2000);
}

@Then("click on the profile link {string}")
public void click_on_the_profile_link(String url) {
    driver.get(url);
}

@Then("upload the jpg profile image")
public void upload_the_jpg_profile_image() {
    lp.upload_jpgfile();
    }

@Then("click on save button")
public void click_on_save_button() throws InterruptedException {
	lp.save_btn();
	Thread.sleep(3000);
}

@And("closes the browser")
public void closes_the_browser() {
	driver.quit();
}

@Then("upload the png profile image")
public void upload_the_png_profile_image() {
    lp.upload_pngfile();
    }

@Then("upload the Gif profile image")
public void upload_the_gif_profile_image() {
    lp.upload_giffile();
    }

@Then("upload the doc profile image")
public void upload_the_doc_profile_image() {
    lp.upload_docfile();
    }

@Then("error msg is displayed")
public void error_msg_is_displayed() {
	lp.docnot_allowed();
}

@Then("upload more mb jpg profile image")
public void upload_more_mb_jpg_profile_image() {
    lp.upload_morembjpgfile();
    }

@Then("Size Exceeded msg is displayed")
public void size_exceeded_msg_is_displayed() {
	lp.Exceeded_file();
}

@Then("upload more mb png profile image")
public void upload_more_mb_png_profile_image() {
    lp.upload_morembpngfile();
    }


}
